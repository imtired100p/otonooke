# otonooke
an ai assistant whith learning code
